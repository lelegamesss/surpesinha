ddocument.getElementById("sim").addEventListener("click", function() {
    document.getElementById("message").textContent = "EBA AINDA BEM QUE VC ACEITOU";
    document.getElementById("message").style.color = "#4CAF50";
    setTimeout(() => {
        document.body.style.backgroundColor = "#ffebf1";
        alert("ainda bem que aceitou se não eu colocaria fogo em vc dormindo");
    }, 1000);
});

document.getElementById("nao").addEventListener("mouseover", function() {
    let x = Math.random() * 80;
    let y = Math.random() * 80;
    this.style.position = "absolute";
    this.style.top = `${y}%`;
    this.style.left = `${x}%`;
    this.style.transition = "all 0.5s ease";
});

document.getElementById("nao").addEventListener("click", function(event) {
    event.preventDefault();
    // Fazendo o botão "não" continuar se movendo após clicar
    this.style.position = "absolute";
    let x = Math.random() * 80;
    let y = Math.random() * 80;
    this.style.top = `${y}%`;
    this.style.left = `${x}%`;
});

